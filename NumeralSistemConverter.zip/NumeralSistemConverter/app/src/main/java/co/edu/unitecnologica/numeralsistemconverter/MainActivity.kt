package co.edu.unitecnologica.numeralsistemconverter

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import kotlinx.android.synthetic.main.activity_main.*
import android.view.View
import android.widget.*
import java.net.*

class MainActivity : AppCompatActivity(),AdapterView.OnItemSelectedListener {

    val conversiones = arrayListOf<String>("Binario","Octal","Hexadecimal","Decimal")


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Combobox.onItemSelectedListener
        Combobox2.onItemSelectedListener
        val aa = ArrayAdapter(this, android.R.layout.simple_spinner_item, conversiones)
        // Set layout to use when the list of choices appear
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        // Set Adapter to Spinner
        Combobox!!.setAdapter(aa)
        Combobox2!!.setAdapter(aa)


        convertir.setOnClickListener {

            if(Combobox.selectedItemPosition == 0 && Combobox2.selectedItemPosition == 1){

                bin_oct(dato.text.toString())


            }else if(Combobox.selectedItemPosition == 0 && Combobox2.selectedItemPosition == 2){
                bin_hex(dato.text.toString())

            }else if(Combobox.selectedItemPosition == 0 && Combobox2.selectedItemPosition == 3){
                bin_dec(dato.text.toString())

            }else if(Combobox.selectedItemPosition == 1 && Combobox2.selectedItemPosition == 0){
                oct_bin(dato.text.toString())

            }else if(Combobox.selectedItemPosition == 1 && Combobox2.selectedItemPosition == 2){
                oct_hex(dato.text.toString())

            }else if(Combobox.selectedItemPosition == 1 && Combobox2.selectedItemPosition == 3){
                oct_dec(dato.text.toString())

            }else if(Combobox.selectedItemPosition == 2 && Combobox2.selectedItemPosition == 0){
                hex_bin(dato.text.toString())

            }else if(Combobox.selectedItemPosition == 2 && Combobox2.selectedItemPosition == 1){
                hex_oct(dato.text.toString())

            }else if(Combobox.selectedItemPosition == 2 && Combobox2.selectedItemPosition == 3){
                hex_dec(dato.text.toString())

            }else if(Combobox.selectedItemPosition == 3 && Combobox2.selectedItemPosition == 0){
                dec_bin(dato.text.toString())

            }else if(Combobox.selectedItemPosition == 3 && Combobox2.selectedItemPosition == 1){
                dec_oct(dato.text.toString())

            }else if(Combobox.selectedItemPosition == 3 && Combobox2.selectedItemPosition == 2){
                dec_hex(dato.text.toString())

            }

        }



        detalles.setOnClickListener {

            val result = URL("https://jsonplaceholder.typicode.com/posts/1").readText()
            noticia.text = result
        }

    }
    override fun onItemSelected(arg0: AdapterView<*>, arg1: View, position: Int, id: Long) {

    }

    override fun onNothingSelected(arg0: AdapterView<*>) {

    }

    fun dec_bin(valor: String) {
        var valor = valor
        val dec = Integer.parseInt(valor)
        valor = Integer.toBinaryString(dec)
        resultado.text = "BINARIO: " + valor
    }

    fun dec_hex(valor: String) {
        var valor = valor
        val dec = Integer.parseInt(valor)
        valor = Integer.toHexString(dec)
        resultado.text ="HEXADECIMAL: " + valor
    }

    fun dec_oct(valor: String) {
        var valor = valor
        val dec = Integer.parseInt(valor)
        valor = Integer.toOctalString(dec)
        resultado.text ="OCTAL: " + valor
    }

    fun bin_dec(valor: String) {
        val dec = Integer.parseInt(valor, 2)
        resultado.text =("DECIMAL: " + dec)
    }

    fun bin_hex(valor: String) {
        var valor = valor
        val dec = Integer.parseInt(valor, 2)
        valor = Integer.toHexString(dec)
        resultado.text =("HEXADECIMAL: " + valor)
    }

    fun bin_oct(valor: String) {
        var valor = valor
        val dec = Integer.parseInt(valor, 2)
        valor = Integer.toOctalString(dec)
        resultado.text =("OCTAL: " + valor)
    }

    fun hex_dec(valor: String) {
        val dec = Integer.parseInt(valor, 16)
        resultado.text =("DECIMAL: " + dec)
    }

    fun hex_bin(valor: String) {
        var valor = valor
        val dec = Integer.parseInt(valor, 16)
        valor = Integer.toBinaryString(dec)
        resultado.text =("BINARIO: " + valor)

    }

    fun hex_oct(valor: String) {
        var valor = valor
        val dec = Integer.parseInt(valor, 16)
        valor = Integer.toOctalString(dec)
        resultado.text =("OCTAL: " + valor)
    }

    fun oct_dec(valor: String) {
        val dec = Integer.parseInt(valor, 8)
        resultado.text =("DECIMAL: " + dec)
    }

    fun oct_bin(valor: String) {
        var valor = valor
        val dec = Integer.parseInt(valor, 8)
        valor = Integer.toBinaryString(dec)
        resultado.text =("BINARIO: " + valor)
    }

    fun oct_hex(valor: String) {
        var valor = valor
        val dec = Integer.parseInt(valor, 8)
        valor = Integer.toHexString(dec)
        resultado.text =("HEXADECIMAL: " + valor)
    }
}


